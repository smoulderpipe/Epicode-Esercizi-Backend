package it.epicode.gestioneEventi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioneEventiApplicationTests {

	@Test
	void contextLoads() {
	}

}
